<template>
  <VueCardCarousel />
</template>

<script setup>
// import HelloWorld from '@/components/HelloWorld.vue'
import VueCardCarousel from '@/components/VueCardCarousel'

</script>
